﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;

namespace SQLSourceEmulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /* get data sources */
            DataTable dt = SqlDataSourceEnumerator.Instance.GetDataSources();

            /* Do whatever you want to do with that table; */

            comboBox1.Items.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                comboBox1.Items.Add(dr[0].ToString());
            }

            dataGridView1.DataSource = dt;
       }
    }
}
